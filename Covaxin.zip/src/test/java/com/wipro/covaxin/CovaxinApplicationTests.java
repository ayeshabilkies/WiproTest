package com.wipro.covaxin;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CovaxinApplicationTests {

	@Test
	void contextLoads() {
	}

}
